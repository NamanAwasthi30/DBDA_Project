#!/bin/bash

#cd ~
#cd mishika/source/
#mkdir $(date +"%m_%d_%Y")
#cd $(date +"%m_%d_%Y")

cd /home/talentum/shared/Project/Project_codes/source/
rm -r *.json

stockList="AAPL KO NFLX BRK.B DIS IBM VZ WMT GE TSLA MA AMZN MSFT UN V"

for stock in $stockList;
do
	wget -O $stock.json https://financialmodelingprep.com/api/v3/historical-price-full/$stock?apikey=WAitrN1PEcPHKKuucTFtgfnpDD1d2KIu
done

