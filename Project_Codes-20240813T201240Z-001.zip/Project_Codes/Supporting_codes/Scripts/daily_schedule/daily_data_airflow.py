import airflow.utils.dates
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator

dag=DAG(
    dag_id='Investment_Analysis_Project',
    description='daily_download_stock_data',
    start_date=airflow.utils.dates.days_ago(5),
    schedule_interval="@daily",
)
bashop=BashOperator(
    task_id='download_stock_data',
    bash_command="/home/talentum/shared/project/Project_codes/source/daily_data.sh ",
    dag=dag
)
sparksub=SparkSubmitOperator(
    application='/home/talentum/shared/project/Project_codes/source/hive_daily_upload.py',
    conn_id='spark_default',
    task_id='hive_upload',
    dag=dag
)
bashop >> sparksub