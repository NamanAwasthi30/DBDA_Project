#!/bin/bash

cd /home/talentum/csvfile_demo
mkdir /home/talentum/shared/grafana/demo/$(date +"%m_%d_%Y")
mv /home/talentum/shared/grafana/demo/portfolio_details.csv /home/talentum/shared/grafana/demo/$(date +"%m_%d_%Y")/
cp part* /home/talentum/shared/grafana/demo/portfolio_details.csv
